import React, { useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import AuthService from './auth';
import ProtectedRoute from './ProtectedRoute';
import Sidebar from './Sidebar';
import Login from './Login';
import Dashboard from './Dashboard';
import ParkInfo from './ParkInfo';
import Training from './Training';
import ManageGuides from './ManageGuides';
import Forbidden from './Forbidden';

function App() {
  console.log('App loaded');
  const [user, setUser] = useState(AuthService.getCurrentUser());
  const handleLogin = () => setUser(AuthService.getCurrentUser());
  const handleLogout = () => { AuthService.logout(); setUser(null); };

  return (
    <div className="app-container">
      <h1>🔥 App is rendering</h1>
      {user && <Sidebar role={user.role} onLogout={handleLogout} />}
      <div className="main-content">
        <Routes>
          <Route path="/login" element={<Login onLogin={handleLogin} />} />
          <Route path="/dashboard" element={
            <ProtectedRoute allowedRoles={['admin','guide','visitor']}><Dashboard /></ProtectedRoute>} />
          <Route path="/park-info" element={
            <ProtectedRoute allowedRoles={['admin','guide','visitor']}><ParkInfo /></ProtectedRoute>} />
          <Route path="/training" element={
            <ProtectedRoute allowedRoles={['admin','guide']}><Training /></ProtectedRoute>} />
          <Route path="/manage-guides" element={
            <ProtectedRoute allowedRoles={['admin']}><ManageGuides /></ProtectedRoute>} />
          <Route path="/forbidden" element={<Forbidden />} />
          <Route path="/" element={<Navigate to="/login" replace />} />
          <Route path="*" element={<Navigate to="/login" replace />} />

        </Routes>
      </div>
    </div>
  );
}

export default App;