import React from 'react';

function Training() {
  return <div><h2>Training</h2><p>Only accessible to guides and admins.</p></div>;
}

export default Training;