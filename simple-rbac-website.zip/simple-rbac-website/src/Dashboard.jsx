import React from 'react';
import AuthService from './auth';

function Dashboard() {
  const role = AuthService.getRole();
  return (
    <div>
      <h2>Dashboard</h2>
      <p>Welcome! You are logged in as <strong>{role}</strong>.</p>
    </div>
  );
}

export default Dashboard;