import React from 'react';

function ParkInfo() {
  return <div><h2>Park Information</h2><p>This is accessible to everyone.</p></div>;
}

export default ParkInfo;