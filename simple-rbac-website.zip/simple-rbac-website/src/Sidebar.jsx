import React from 'react';
import { Link, useNavigate } from 'react-router-dom';

function Sidebar({ role, onLogout }) {
  const navigate = useNavigate();
  return (
    <aside className="sidebar">
      <nav>
        <ul>
          <li><Link to="/dashboard">Dashboard</Link></li>
          <li><Link to="/park-info">Park Info</Link></li>
          {(role === 'admin' || role === 'guide') && <li><Link to="/training">Training</Link></li>}
          {role === 'admin' && <li><Link to="/manage-guides">Manage Guides</Link></li>}
          <li><button onClick={() => { onLogout(); navigate('/login'); }}>Logout</button></li>
        </ul>
      </nav>
    </aside>
  );
}

export default Sidebar;