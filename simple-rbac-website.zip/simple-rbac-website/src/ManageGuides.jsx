import React from 'react';

function ManageGuides() {
  return <div><h2>Manage Guides</h2><p>Admin-only area.</p></div>;
}

export default ManageGuides;