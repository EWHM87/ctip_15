import React from 'react';
import { Navigate } from 'react-router-dom';
import AuthService from './auth';

function ProtectedRoute({ allowedRoles, children }) {
  if (!AuthService.isLoggedIn()) return <Navigate to="/login" replace />;
  const userRole = AuthService.getRole();
  return allowedRoles.includes(userRole) ? children : <Navigate to="/forbidden" replace />;
}

export default ProtectedRoute;