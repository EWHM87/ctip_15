// SpeciesDatabase.jsx
import React from 'react';

function SpeciesDatabase() {
  return (
    <div className="container mt-4">
      <h2>📚 View Species Records</h2>
      <p>This page displays a searchable database of previously identified species.</p>
      {/* Table or card view of species info */}
    </div>
  );
}

export default SpeciesDatabase;
