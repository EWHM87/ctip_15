// script.js

function showAlert() {
    alert("Form submitted successfully!");
}
